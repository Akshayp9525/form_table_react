// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// function App() {
//   const [dataArray, setDataArray] = useState([]);
//   const [newData, setNewData] = useState({ name: '', description: '' });

//   useEffect(() => {
//     axios.get('https://api.nytimes.com/svc/topstories/v2/science.json?api-key=JCO9htL7LKTjvSa2srchgr5zixtdVtMf')
//       .then(response => {
//         setDataArray(response.data.results);
//       })
//       .catch(error => {
//         console.error(error);
//       });
//   }, []);

//   const handleInputChange = (event) => {
//     const { name, value } = event.target;
//     setNewData({ ...newData, [name]: value });
//   };

//   const handleFormSubmit = (event) => {
//     event.preventDefault();
//     axios.post('https://api.nytimes.com/svc/topstories/v2/science.json?api-key=JCO9htL7LKTjvSa2srchgr5zixtdVtMf', newData)
//       .then(response => {
//         setDataArray([...dataArray, response.data]);
//         setNewData({ name: '', description: '' });
//       })
//       .catch(error => {
//         console.error(error);
//       });
//   };

//   return (
//     <div>
//       <form onSubmit={handleFormSubmit}>
//         <label>
//           Name:
//           <input type="text" name="name" value={newData.name} onChange={handleInputChange} />
//         </label>
//         <label>
//           Description:
//           <input type="text" name="description" value={newData.description} onChange={handleInputChange} />
//         </label>
//         <button type="submit">Add Data</button>
//       </form>
//       {dataArray?.map((data, index) => (
//         <div key={index}>
//           <p>{data.title}</p>
//           <p>{data.abstract}</p>
//         </div>
//       ))}
//     </div>
//   );
// }

// export default App;
