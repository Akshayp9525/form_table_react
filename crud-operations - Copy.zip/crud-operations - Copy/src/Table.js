
import './Crud.css'

function Table({ tableData , OnDelete ,OnEdit }) {

    return (
      <table className="table">
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Profile</th>
            <th>update/Delete</th>
          </tr>
        </thead>
        <tbody>
          {tableData.map((data, index) => {
            return (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{data.name}</td>
                <td>{data.email}</td>
                <td>{data.profile}</td>
                <td><button className="modifier" id='Edit' onClick={()=>OnEdit(index)}>edit</button>
                <button className="modifier" id='Delete' onClick={()=>OnDelete(index)}>Delete</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    );
  }
  export default Table;