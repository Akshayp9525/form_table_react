import React from "react";
import "./Crud.css";
function SearchBar({ handlSearch }) {
  return (
    <div className="searchbar">
      <nav className="navbar navbar-light bg-light">
        <form className="form-inline">
          <input
            className="form-control mr-sm-2"
            type="search"
            placeholder="Search"
            aria-label="Search"
            onChange={(e) => handlSearch(e)}
          />
        </form>
      </nav>
    </div>
  );
}

export default SearchBar;
