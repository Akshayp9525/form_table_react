import React, { useState, Fragment } from "react";
import Form from "./Form";
import Table from "./Table";

function Profile() {
  const [tableData, setTableData] = useState([]);
  const [formErros, setFormErrors] = useState(false);
  const [formObject, setFormObject] = useState({
    name: "",
    email: "",
    profile: "",
  });
  const validate = (values) => {
    console.log("validate");
    const errors = {};
    const regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+).*$/;
    if (!formObject.name) {
      errors.name = "Username is required!";
      setFormErrors(errors);
      return false;
    }
    if (!formObject.email) {
      errors.email = "Email is required!";
      setFormErrors(errors);
      return false;
    } else if (!regex.test(values.email)) {
      errors.email = "This is not a valid email format!";
      setFormErrors(errors);
      return false;
    }
    if (!formObject.profile) {
      errors.profile = "Email is required!";
      setFormErrors(errors);
      return false;
    } 
    
    setFormErrors(errors)
    console.log("errors", errors);
    return true;
  };
  const OnEdit = (currentIndex) => {
    console.log(currentIndex);
    const editedData = tableData[currentIndex];
    setFormObject(editedData);
    const newData = [...tableData];
    newData.splice(currentIndex, 1);
    setTableData(newData);
  };

  const handleDelete = (currentIndex) => {
    console.log(currentIndex);
    const filterData = tableData.filter(
      (item, index) => index !== currentIndex
    );
    setTableData(filterData);
  };
  const onValChange = (event) => {
    const value = (res) => ({
      ...res,
      [event.target.name]: event.target.value,
    });
    setFormObject(value);
  };
  const onFormSubmit = (event) => {
    event.preventDefault();
    validate();
    if (!validate()) {
      const checkVal = !Object.values(formObject).every((res) => res === "");
      if (checkVal) {
        const dataObj = (data) => [...data, formObject];
        setTableData(dataObj);
        const isEmpty = { name: "", email: "", profile: "" };
        setFormObject(isEmpty);
      }
    }
  };
  return (
    <Fragment>
      <Form
        onValChange={onValChange}
        formObject={formObject}
        onFormSubmit={onFormSubmit}
        formErros={formErros}
      />
      <Table tableData={tableData} OnDelete={handleDelete} OnEdit={OnEdit} />
    </Fragment>
  );
}

export default Profile;
