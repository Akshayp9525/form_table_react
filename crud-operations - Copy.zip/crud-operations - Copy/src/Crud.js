import React, { useState, Fragment } from "react";
import Form from "./Form";
import Table from "./Table";
import SearchBar from "./SearchBar";

function Profile() {
  const [tableData, setTableData] = useState([]);
  const [searchData, setSearchData] = useState([]);
  const [formErrors, setFormErrors] = useState({});
  // const [query, setQuery] = useState([]);

  const [formObject, setFormObject] = useState({
    name: "",
    email: "",
    profile: "",
  });
  const [isError, setIsError] = useState(true);

  const validate = (values) => {
    const errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.name) {
      errors.name = "Username is required!";
      setFormErrors(errors);
      setIsError(false);
    }

    if (!values.email) {
      errors.email = "Email is required!";
      setFormErrors(errors);
      setIsError(false);
    } else if (!regex.test(values.email)) {
      errors.email = "This is not a valid email format!";
      setFormErrors(errors);
      setIsError(false);
    }
    if (!values.profile) {
      errors.profile = "profile is required!";
      setFormErrors(errors);
      setIsError(false);
    }

    setFormErrors(errors);
    return errors;
  };
  const handlSearch = (event) => {
    console.log("event", event);
    // setQuery(event.target.value);
    filterData(event.target.value);
  };

  // filter records by search text
  const filterData = (value) => {
    const lowercasedValue = value.toLowerCase().trim();
    console.log("filter data", lowercasedValue)
    if (lowercasedValue === "") 
    {

      setSearchData(tableData);
    }
    else {
      const filteredData = tableData.filter((item) => {
        return Object.keys(item).some((key) =>
          item[key].toString().toLowerCase().includes(lowercasedValue)
        );
      });
      setSearchData(filteredData);
    }
  };
  const OnEdit = (currentIndex) => {
    const editedData = tableData[currentIndex];
    setFormObject(editedData);
    const newData = [...tableData];
    newData.splice(currentIndex, 1);
    setTableData(newData);
  };

  const handleDelete = (currentIndex) => {
    const filterData = tableData.filter(
      (item, index) => index !== currentIndex
    );
    setTableData(filterData);
  };

  const onValChange = (event) => {
    const value = (res) => ({
      ...res,
      [event.target.name]: event.target.value,
    });
    setFormObject(value);
  };

  const onFormSubmit = (event) => {
    event.preventDefault();
    const errors = validate(formObject);
    if (Object.keys(errors).length === 0) {
      const checkVal = !Object.values(formObject).every((res) => res === "");
      if (checkVal) {
        const dataObj = (data) => [...data, formObject];
        setTableData(dataObj);
        const isEmpty = { name: "", email: "", profile: "" };
        setFormObject(isEmpty);
      }
    }
  };
  return (
    <Fragment>
      <Form
        onValChange={onValChange}
        formObject={formObject}
        onFormSubmit={onFormSubmit}
        formErrors={formErrors}
        isError={isError}
      />
      <SearchBar handlSearch={handlSearch} />

      <Table tableData={searchData} OnDelete={handleDelete} OnEdit={OnEdit} />
    </Fragment>
  );
}

export default Profile;
