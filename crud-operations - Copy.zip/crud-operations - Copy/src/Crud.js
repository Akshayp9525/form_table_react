import React, { useState, Fragment } from "react";
import Form from "./Form";
import Table from "./Table";

function Profile() {
  const [tableData, setTableData] = useState([]);
  const [formErrors, setFormErrors] = useState({});
  const [formObject, setFormObject] = useState({
    name: "",
    email: "",
    profile: "",
  });
  const [isError, setIsError] = useState(true);
  console.log("object", formErrors);

  const validate = (values) => {
    const errors = {};
    console.log("valuesss", values);
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.name) {
      errors.name = "Username is required!";
      setFormErrors(errors);
      setIsError(false);
    }
   
    if (!values.email) {
      console.log("values", values.email);
      errors.email = "Email is required!";
      setFormErrors(errors);
      setIsError(false);
    }
    if (!values.profile ) {
      errors.profile = "profile is required!";
      setFormErrors(errors);
      setIsError(false);
    } else if (!regex.test(values.email)) {
      errors.email = "This is not a valid email format!";
      setFormErrors(errors);
      setIsError(false);
    }

    setFormErrors(errors);
    console.log("errors", errors);
    return errors;
  };

  const OnEdit = (currentIndex) => {
    console.log(currentIndex);
    const editedData = tableData[currentIndex];
    setFormObject(editedData);
    const newData = [...tableData];
    newData.splice(currentIndex, 1);
    setTableData(newData);
  };

  const handleDelete = (currentIndex) => {
    console.log(currentIndex);
    const filterData = tableData.filter(
      (item, index) => index !== currentIndex
    );
    setTableData(filterData);
  };

  const onValChange = (event) => {
    const value = (res) => ({
      ...res,
      [event.target.name]: event.target.value,
    });
    setFormObject(value);
  };

  const onFormSubmit = (event) => {
    event.preventDefault();
    console.log("formObject", formObject);
    const errors = validate(formObject);
    if (Object.keys(errors).length === 0) {
      const checkVal = !Object.values(formObject).every((res) => res === "");
      if (checkVal) {
        const dataObj = (data) => [...data, formObject];
        setTableData(dataObj);
        const isEmpty = { name: "", email: "", profile: "" };
        setFormObject(isEmpty);
      }
    }
  };
  return (
    <Fragment>
      <Form
        onValChange={onValChange}
        formObject={formObject}
        onFormSubmit={onFormSubmit}
        formErrors={formErrors}
        isError={isError}
      />
      <Table tableData={tableData} OnDelete={handleDelete} OnEdit={OnEdit} />
    </Fragment>
  );
}

export default Profile;
