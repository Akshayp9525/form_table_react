// import React, { useState ,useEffect} from 'react'
// import axios from 'axios';
// function ApiCalling() {
//   const [post,setPost] = useState([]);
//   useEffect(()=>
//   {
//         axios.get('https://api.nytimes.com/svc/topstories/v2/science.json?api-key=JCO9htL7LKTjvSa2srchgr5zixtdVtMf')
//         .then(response => {
//             setPost(response.data.results);
//             console.log(response.data.results);
//         })
//         .catch(error => {
//         console.error(error);
//         });
// }, []);

//   return (
//     <>
    
//     <div>
//     {post?.map((data, index) => {
//         return (
// <div key={index}>
//             <p>{data.section}</p>
           
//         </div>
//         )
//     }
//     )}
//   </div>
 
//     </>
// );

// }

// export default ApiCalling
